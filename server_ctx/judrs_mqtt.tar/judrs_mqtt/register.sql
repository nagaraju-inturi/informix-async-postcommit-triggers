execute procedure sqlj.install_jar
  ('file:$INFORMIXDIR/jars/mqtt_trigger.jar',
    'mqtt_trigger_jar',
    1);
